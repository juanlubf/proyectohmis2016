<?php	
	//Archivo con las variables constantes que se van a usar
	
	$host = "localhost";
	$user = "root";
	$password = "";
	$database = "webapp";
